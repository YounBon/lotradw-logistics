# LoTraDW Admin Dashboard FullStack

## 🚀 How to Run

### 1. Database
- Start MySQL
- Run database/schema.sql in MySQL Workbench or VS Code SQLTools:
  ```sql
  CREATE DATABASE lotradw;
  USE lotradw;
  SOURCE ./database/schema.sql;
  ```

### 2. Backend
```bash
cd backend
npm install
npm start
```
Backend runs at http://localhost:5000

### 3. Frontend
```bash
cd frontend
npm install
npm start
```
Frontend runs at http://localhost:3000
