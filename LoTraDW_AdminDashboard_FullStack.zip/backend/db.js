const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456', // đổi thành mật khẩu MySQL của bạn
  database: 'lotradw'
});

module.exports = pool.promise();
