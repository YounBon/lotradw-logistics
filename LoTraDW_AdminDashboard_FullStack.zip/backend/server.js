const express = require('express');
const cors = require('cors');
const db = require('./db');
const usersRouter = require('./routes/users');
const ordersRouter = require('./routes/orders');
const productsRouter = require('./routes/products');
const shipmentsRouter = require('./routes/shipments');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/users', usersRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/products', productsRouter);
app.use('/api/shipments', shipmentsRouter);

app.get('/api/stats', async (req, res) => {
  try {
    const [[users]] = await db.query('SELECT COUNT(*) as count FROM users');
    const [[orders]] = await db.query('SELECT COUNT(*) as count FROM orders');
    const [[products]] = await db.query('SELECT COUNT(*) as count FROM products');
    const [[shipments]] = await db.query('SELECT COUNT(*) as count FROM shipments');
    res.json({users:users.count, orders:orders.count, products:products.count, shipments:shipments.count});
  } catch (err) {
    res.status(500).json({error: err.message});
  }
});

app.get('/api/orders/chart', async (req, res) => {
  try {
    const [rows] = await db.query("SELECT DATE_FORMAT(order_date,'%Y-%m') as month, COUNT(*) as count FROM orders GROUP BY month");
    res.json(rows);
  } catch (err) {
    res.status(500).json({error: err.message});
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
