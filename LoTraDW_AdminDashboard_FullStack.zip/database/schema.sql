DROP TABLE IF EXISTS shipments;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  role VARCHAR(50)
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  price DECIMAL(10,2)
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  product_id INT,
  quantity INT,
  order_date DATE,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE shipments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  carrier VARCHAR(100),
  status VARCHAR(50),
  shipped_date DATE,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Seed data
INSERT INTO users (name,email,role) VALUES
('Nguyen Van A','a@example.com','admin'),
('Tran Thi B','b@example.com','customer'),
('Le Van C','c@example.com','customer');

INSERT INTO products (name,price) VALUES
('Laptop',1500.00),
('Phone',800.00),
('Tablet',600.00);

INSERT INTO orders (user_id,product_id,quantity,order_date) VALUES
(1,1,1,'2025-01-10'),
(2,2,2,'2025-02-15'),
(3,3,1,'2025-03-05');

INSERT INTO shipments (order_id,carrier,status,shipped_date) VALUES
(1,'VNPost','Delivered','2025-01-15'),
(2,'DHL','In Transit','2025-02-20'),
(3,'FedEx','Pending','2025-03-10');
