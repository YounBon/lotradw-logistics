import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Orders from './pages/Orders';
import Products from './pages/Products';
import Shipments from './pages/Shipments';

function App() {
  const [page, setPage] = useState('dashboard');

  let content;
  if (page === 'dashboard') content = <Dashboard />;
  if (page === 'users') content = <Users />;
  if (page === 'orders') content = <Orders />;
  if (page === 'products') content = <Products />;
  if (page === 'shipments') content = <Shipments />;

  return (
    <div className="flex h-screen">
      <Sidebar setPage={setPage} />
      <div className="flex-1 flex flex-col">
        <Navbar />
        <div className="p-4 overflow-auto">{content}</div>
      </div>
    </div>
  );
}

export default App;
