import React from 'react';

export default function Navbar() {
  return (
    <div className="bg-white shadow p-4 flex justify-between">
      <span className="font-bold">LoTraDW Admin Dashboard</span>
      <span>User</span>
    </div>
  );
}
