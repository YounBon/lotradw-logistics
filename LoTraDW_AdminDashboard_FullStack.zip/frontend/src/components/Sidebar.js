import React from 'react';

export default function Sidebar({ setPage }) {
  const menus = [
    {key: 'dashboard', label: 'Dashboard'},
    {key: 'users', label: 'Users'},
    {key: 'orders', label: 'Orders'},
    {key: 'products', label: 'Products'},
    {key: 'shipments', label: 'Shipments'},
  ];
  return (
    <div className="w-64 bg-gray-800 text-white flex flex-col">
      <h2 className="text-2xl font-bold p-4">LoTraDW</h2>
      {menus.map(m => (
        <button key={m.key} className="p-3 text-left hover:bg-gray-700" onClick={() => setPage(m.key)}>
          {m.label}
        </button>
      ))}
    </div>
  );
}
