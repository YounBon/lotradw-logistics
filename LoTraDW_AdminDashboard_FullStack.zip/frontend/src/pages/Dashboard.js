import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const [stats, setStats] = useState({users:0, orders:0, products:0, shipments:0});
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/stats').then(res => setStats(res.data));
    axios.get('http://localhost:5000/api/orders/chart').then(res => setChartData(res.data));
  }, []);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Overview</h2>
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white shadow rounded p-4">Users: {stats.users}</div>
        <div className="bg-white shadow rounded p-4">Orders: {stats.orders}</div>
        <div className="bg-white shadow rounded p-4">Products: {stats.products}</div>
        <div className="bg-white shadow rounded p-4">Shipments: {stats.shipments}</div>
      </div>
      <div className="bg-white shadow rounded p-4 h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
