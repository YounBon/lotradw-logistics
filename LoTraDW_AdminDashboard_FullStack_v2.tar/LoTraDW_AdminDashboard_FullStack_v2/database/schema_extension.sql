-- Carrier tables
CREATE TABLE carriers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  contact VARCHAR(100),
  phone VARCHAR(20)
);

CREATE TABLE carrier_schedules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  carrier_id INT,
  schedule_date DATE,
  route VARCHAR(200),
  FOREIGN KEY (carrier_id) REFERENCES carriers(id)
);

-- Seed data
INSERT INTO carriers (name, contact, phone) VALUES
('VNPost', 'Nguyen Van A', '0901234567'),
('DHL', 'Tran Thi B', '0912345678');

INSERT INTO carrier_schedules (carrier_id, schedule_date, route) VALUES
(1, '2025-02-10', 'Hanoi → HCMC'),
(2, '2025-02-11', 'Danang → Hue');
