import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function CarrierSchedules() {
  const [schedules, setSchedules] = useState([]);

  const load = () => {
    axios.get('http://localhost:5000/api/carrier-schedules').then(res => setSchedules(res.data));
  };

  useEffect(() => { load(); }, []);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Carrier Schedules</h2>
      <table className="w-full bg-white shadow rounded">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">ID</th>
            <th className="p-2">Carrier ID</th>
            <th className="p-2">Date</th>
            <th className="p-2">Route</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map(s => (
            <tr key={s.id} className="border-t">
              <td className="p-2">{s.id}</td>
              <td className="p-2">{s.carrier_id}</td>
              <td className="p-2">{s.schedule_date}</td>
              <td className="p-2">{s.route}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
