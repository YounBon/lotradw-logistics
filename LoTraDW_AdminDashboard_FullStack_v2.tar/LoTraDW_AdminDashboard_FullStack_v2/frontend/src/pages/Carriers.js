import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Carriers() {
  const [carriers, setCarriers] = useState([]);

  const load = () => {
    axios.get('http://localhost:5000/api/carriers').then(res => setCarriers(res.data));
  };

  useEffect(() => { load(); }, []);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Carriers</h2>
      <table className="w-full bg-white shadow rounded">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">ID</th>
            <th className="p-2">Name</th>
            <th className="p-2">Contact</th>
            <th className="p-2">Phone</th>
          </tr>
        </thead>
        <tbody>
          {carriers.map(c => (
            <tr key={c.id} className="border-t">
              <td className="p-2">{c.id}</td>
              <td className="p-2">{c.name}</td>
              <td className="p-2">{c.contact}</td>
              <td className="p-2">{c.phone}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
