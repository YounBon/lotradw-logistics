
LoTraDW Admin Dashboard FullStack (v3)
=====================================

How to run
----------
1. Start MySQL server.
2. Import database schema:
   - Using Workbench or SQLTools: run file database/schema.sql
   - Or from command line (MySQL installed):
     mysql -u root -p
     CREATE DATABASE lotradw;
     USE lotradw;
     SOURCE path/to/database/schema.sql;

3. Backend:
   cd backend
   npm install
   npm start
   (backend runs at http://localhost:5000)

4. Frontend:
   cd frontend
   npm install
   npm start
   (frontend runs at http://localhost:3000)

Notes:
- Default DB connection in backend/db.js uses user 'root' and password '123456'. Change as needed.
- This package contains frontend (React+Tailwind), backend (Express+mysql2), and DB schema with seed data.
