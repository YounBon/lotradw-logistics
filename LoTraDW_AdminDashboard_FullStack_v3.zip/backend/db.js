const mysql = require('mysql2');
    const pool = mysql.createPool({
      host: 'localhost',
      user: 'root',
      password: '123456', // change to your MySQL root password
      database: 'lotradw',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    module.exports = pool.promise();