const express = require('express');
    const cors = require('cors');
    const db = require('./db');
    const users = require('./routes/users');
    const orders = require('./routes/orders');
    const products = require('./routes/products');
    const shipments = require('./routes/shipments');
    const carriers = require('./routes/carriers');
    const carrierSchedules = require('./routes/carrier-schedules');

    const app = express();
    app.use(cors()); app.use(express.json());

    app.use('/api/users', users);
    app.use('/api/orders', orders);
    app.use('/api/products', products);
    app.use('/api/shipments', shipments);
    app.use('/api/carriers', carriers);
    app.use('/api/carrier-schedules', carrierSchedules);

    app.get('/api/stats', async (req,res)=>{
      try{
        const [[u]] = await db.query('SELECT COUNT(*) as count FROM users');
        const [[o]] = await db.query('SELECT COUNT(*) as count FROM orders');
        const [[p]] = await db.query('SELECT COUNT(*) as count FROM products');
        const [[s]] = await db.query('SELECT COUNT(*) as count FROM shipments');
        const [[c]] = await db.query('SELECT COUNT(*) as count FROM carriers');
        res.json({users:u.count, orders:o.count, products:p.count, shipments:s.count, carriers:c.count});
      }catch(err){ res.status(500).json({error:err.message}); }
    });

    app.get('/api/orders/chart', async (req,res)=>{
      try{
        const [rows] = await db.query("SELECT DATE_FORMAT(order_date,'%Y-%m') as month, COUNT(*) as count FROM orders GROUP BY month");
        res.json(rows);
      }catch(err){ res.status(500).json({error:err.message}); }
    });

    const PORT = 5000; app.listen(PORT, ()=>console.log('Backend running on http://localhost:'+PORT));