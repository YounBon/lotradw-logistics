import React from 'react';
    export default function Navbar(){
      return (
        <header className="bg-white shadow p-4 flex justify-between items-center">
          <div className="text-lg font-semibold">Admin Dashboard</div>
          <div className="text-sm text-gray-600">Admin</div>
        </header>
      );
    }