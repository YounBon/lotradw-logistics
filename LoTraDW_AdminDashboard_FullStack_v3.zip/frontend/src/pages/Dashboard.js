import React, {useEffect, useState} from 'react';
    import axios from 'axios';
    import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

    export default function Dashboard(){
      const [stats,setStats] = useState({users:0,orders:0,products:0,shipments:0,carriers:0});
      const [chart,setChart] = useState([]);
      useEffect(()=>{
        axios.get('http://localhost:5000/api/stats').then(r=>setStats(r.data)).catch(()=>{});
        axios.get('http://localhost:5000/api/orders/chart').then(r=>setChart(r.data)).catch(()=>{});
      },[]);
      return (
        <div>
          <h1 className="text-2xl font-bold mb-4">Overview</h1>
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-white p-4 rounded shadow">Users <div className="text-2xl font-bold">{stats.users}</div></div>
            <div className="bg-white p-4 rounded shadow">Orders <div className="text-2xl font-bold">{stats.orders}</div></div>
            <div className="bg-white p-4 rounded shadow">Products <div className="text-2xl font-bold">{stats.products}</div></div>
            <div className="bg-white p-4 rounded shadow">Shipments <div className="text-2xl font-bold">{stats.shipments}</div></div>
          </div>
          <div className="bg-white p-4 rounded shadow h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}><XAxis dataKey="month"/><YAxis/><Tooltip/><Bar dataKey="count" fill="#3b82f6"/></BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      );
    }