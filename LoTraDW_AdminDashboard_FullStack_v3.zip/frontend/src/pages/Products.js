import React, {useEffect, useState} from 'react';
    import axios from 'axios';
    export default function Products(){
      const [items,setItems]=useState([]);
      useEffect(()=>{ axios.get('http://localhost:5000/api/products').then(r=>setItems(r.data)).catch(()=>{}); },[]);
      return (<div><h1 className="text-2xl font-bold mb-4">Products</h1><div className="bg-white rounded shadow overflow-auto"><table className="min-w-full"><thead className="bg-gray-100"><tr><th className="p-2">ID</th><th className="p-2">Name</th><th className="p-2">Price</th></tr></thead><tbody>{items.map(p=>(<tr key={p.id} className="border-t"><td className="p-2">{p.id}</td><td className="p-2">{p.name}</td><td className="p-2">{p.price}</td></tr>))}</tbody></table></div></div>);
    }