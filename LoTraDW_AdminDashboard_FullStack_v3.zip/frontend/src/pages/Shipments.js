import React, {useEffect, useState} from 'react';
    import axios from 'axios';
    export default function Shipments(){
      const [list,setList]=useState([]);
      useEffect(()=>{ axios.get('http://localhost:5000/api/shipments').then(r=>setList(r.data)).catch(()=>{}); },[]);
      return (<div><h1 className="text-2xl font-bold mb-4">Shipments</h1><div className="bg-white rounded shadow overflow-auto"><table className="min-w-full"><thead className="bg-gray-100"><tr><th className="p-2">ID</th><th className="p-2">Order</th><th className="p-2">Carrier</th><th className="p-2">Status</th></tr></thead><tbody>{list.map(s=>(<tr key={s.id} className="border-t"><td className="p-2">{s.id}</td><td className="p-2">{s.order_id}</td><td className="p-2">{s.carrier}</td><td className="p-2">{s.status}</td></tr>))}</tbody></table></div></div>);
    }