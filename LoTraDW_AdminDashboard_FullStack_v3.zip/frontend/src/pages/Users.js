import React, {useEffect, useState} from 'react';
    import axios from 'axios';
    export default function Users(){
      const [users,setUsers]=useState([]);
      useEffect(()=>{ axios.get('http://localhost:5000/api/users').then(r=>setUsers(r.data)).catch(()=>{}); },[]);
      return (
        <div>
          <h1 className="text-2xl font-bold mb-4">Users</h1>
          <div className="bg-white rounded shadow overflow-auto">
            <table className="min-w-full">
              <thead className="bg-gray-100"><tr><th className="p-2">ID</th><th className="p-2">Name</th><th className="p-2">Email</th></tr></thead>
              <tbody>{users.map(u=>(<tr key={u.id} className="border-t"><td className="p-2">{u.id}</td><td className="p-2">{u.name}</td><td className="p-2">{u.email}</td></tr>))}</tbody>
            </table>
          </div>
        </div>
      );
    }