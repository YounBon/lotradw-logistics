import React, { useState } from 'react';
    import Sidebar from './components/Sidebar';
    import Navbar from './components/Navbar';
    import Dashboard from './pages/Dashboard';
    import Users from './pages/Users';
    import Orders from './pages/Orders';
    import Products from './pages/Products';
    import Shipments from './pages/Shipments';
    import Carriers from './pages/Carriers';
    import CarrierSchedules from './pages/CarrierSchedules';

    export default function App(){
      const [page, setPage] = useState('dashboard');
      const render = () => {
        switch(page){
          case 'users': return <Users />;
          case 'orders': return <Orders />;
          case 'products': return <Products />;
          case 'shipments': return <Shipments />;
          case 'carriers': return <Carriers />;
          case 'schedules': return <CarrierSchedules />;
          default: return <Dashboard />;
        }
      }
      return (
        <div className="flex h-screen">
          <Sidebar setPage={setPage} active={page} />
          <div className="flex-1 flex flex-col">
            <Navbar />
            <div className="p-6 overflow-auto">{render()}</div>
          </div>
        </div>
      );
    }