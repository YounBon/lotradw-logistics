import React from 'react';
    export default function Sidebar({ setPage, active }){
      const menus = ['dashboard','users','orders','products','shipments','carriers','schedules'];
      const labels = {dashboard:'Dashboard', users:'Users', orders:'Orders', products:'Products', shipments:'Shipments', carriers:'Carriers', schedules:'Schedules'};
      return (
        <aside className="w-64 bg-white border-r">
          <div className="p-6 text-2xl font-bold text-blue-600">LoTraDW</div>
          <nav className="px-2">
            {menus.map(m => (
              <button key={m} onClick={()=>setPage(m)} className={
                "w-full text-left px-4 py-3 rounded-md mb-1 " + (active===m ? "bg-blue-50 text-blue-700 font-semibold" : "hover:bg-gray-100")
              }>{labels[m]}</button>
            ))}
          </nav>
        </aside>
      );
    }