import React, {useEffect, useState} from 'react';
    import axios from 'axios';
    export default function Orders(){
      const [orders,setOrders]=useState([]);
      useEffect(()=>{ axios.get('http://localhost:5000/api/orders').then(r=>setOrders(r.data)).catch(()=>{}); },[]);
      return (<div><h1 className="text-2xl font-bold mb-4">Orders</h1><div className="bg-white rounded shadow overflow-auto"><table className="min-w-full"><thead className="bg-gray-100"><tr><th className="p-2">ID</th><th className="p-2">User</th><th className="p-2">Product</th><th className="p-2">Qty</th></tr></thead><tbody>{orders.map(o=>(<tr key={o.id} className="border-t"><td className="p-2">{o.id}</td><td className="p-2">{o.user_id}</td><td className="p-2">{o.product_id}</td><td className="p-2">{o.quantity}</td></tr>))}</tbody></table></div></div>);
    }